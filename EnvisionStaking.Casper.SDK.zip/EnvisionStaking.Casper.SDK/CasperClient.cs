﻿using EnvisionStaking.Casper.SDK.Model;
using EnvisionStaking.Casper.SDK.Model.AccountBalance;
using EnvisionStaking.Casper.SDK.Model.AccountInfo;
using EnvisionStaking.Casper.SDK.Model.AuctionInfo;
using EnvisionStaking.Casper.SDK.Model.Block;
using EnvisionStaking.Casper.SDK.Model.BlockTransfers;
using EnvisionStaking.Casper.SDK.Model.Deploy;
using EnvisionStaking.Casper.SDK.Model.EraInfo;
using EnvisionStaking.Casper.SDK.Model.NodePeers;
using EnvisionStaking.Casper.SDK.Model.NodeStatus;
using EnvisionStaking.Casper.SDK.Model.StateItem;
using EnvisionStaking.Casper.SDK.Model.StateRootHash;
using EnvisionStaking.Casper.SDK.Services;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace EnvisionStaking.Casper.SDK
{
    public class CasperClient
    {
        public readonly string url;
        public CasperClient(string rpcUrl)
        {
            url = rpcUrl;
        }

        #region StateRootHash
        public StateRootHashResult GetStateRootHash()
        {
            StateRootHashRequest request = new StateRootHashRequest();
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<StateRootHashRequest, StateRootHashResult>(url, request, HttpMethod.Post);
        }

        public StateRootHashResult GetStateRootHashByBlockHash(string hash)
        {
            StateRootHashRequest request = new StateRootHashRequest(hash);
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<StateRootHashRequest, StateRootHashResult>(url, request, HttpMethod.Post);
        }

        public StateRootHashResult GetStateRootHashByHeight(string height)
        {
            StateRootHashRequest request = new StateRootHashRequest(height);
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<StateRootHashRequest, StateRootHashResult>(url, request, HttpMethod.Post);
        }
        #endregion
        #region Account
        public AccountInfoResult GetAccountInfo(string key)
        {
            AccountInfoRequest request = new AccountInfoRequest();
            request.jsonrpc = "2.0";
            request.id = "0";
            request.Parameters.public_key = key; ;

            return RpcService.RpcClient<AccountInfoRequest, AccountInfoResult>(url, request, HttpMethod.Post);
        }
        public string GetAccountHash(string key)
        {
            AccountInfoRequest request = new AccountInfoRequest();
            request.jsonrpc = "2.0";
            request.id = "0";
            request.Parameters.public_key = key; ;

            AccountInfoResult accountInforResult = RpcService.RpcClient<AccountInfoRequest, AccountInfoResult>(url, request, HttpMethod.Post);

            return accountInforResult.result.account.account_hash;
        }
        public string GetAccountMainPurse(string key)
        {
            AccountInfoRequest request = new AccountInfoRequest();
            request.jsonrpc = "2.0";
            request.id = "0";
            request.Parameters.public_key = key; ;

            AccountInfoResult accountInforResult = RpcService.RpcClient<AccountInfoRequest, AccountInfoResult>(url, request, HttpMethod.Post);

            return accountInforResult.result.account.main_purse;
        }
        public AccountBalanceResult GetAccountBalance(string mainPurse, string stateRootHash)
        {
            AccountBalanceRequest request = new AccountBalanceRequest();
            request.jsonrpc = "2.0";
            request.id = "0";
            request.Parameters.purse_uref = mainPurse;
            request.Parameters.state_root_hash = stateRootHash;

            return RpcService.RpcClient<AccountBalanceRequest, AccountBalanceResult>(url, request, HttpMethod.Post);
        }
        public AccountBalanceResult GetAccountBalance(string key)
        {
            AccountInfoResult acountInfoResult = GetAccountInfo(key);
            StateRootHashResult stateRootHashResult = GetStateRootHash();
            return GetAccountBalance(acountInfoResult.result.account.main_purse, stateRootHashResult.result.state_root_hash);
        }
        #endregion

        #region Auction
        public AuctionInfoResult GetAuctionInfo()
        {
            AuctionInfoRequest request = new AuctionInfoRequest();
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<AuctionInfoRequest, AuctionInfoResult>(url, request, HttpMethod.Post);
        }
        #endregion

        #region Block
        public BlockResult GetBlockLast()
        {
            BlockRequest request = new BlockRequest();
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<BlockRequest, BlockResult>(url, request, HttpMethod.Post);
        }

        public BlockResult GetBlockByHash(string hash)
        {
            BlockRequest request = new BlockRequest(hash);
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<BlockRequest, BlockResult>(url, request, HttpMethod.Post);
        }

        public BlockResult GetBlockByHeight(string height)
        {
            BlockRequest request = new BlockRequest(height);
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<BlockRequest, BlockResult>(url, request, HttpMethod.Post);
        }

        public BlockTransfersResult GetBlockTransfersLast()
        {
            BlockTransfersRequest request = new BlockTransfersRequest();
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<BlockTransfersRequest, BlockTransfersResult>(url, request, HttpMethod.Post);
        }

        public BlockTransfersResult GetBlockTransfersByHash(string hash)
        {
            BlockTransfersRequest request = new BlockTransfersRequest(hash);
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<BlockTransfersRequest, BlockTransfersResult>(url, request, HttpMethod.Post);
        }

        public BlockTransfersResult GetBlockTransfersByHeight(string height)
        {
            BlockTransfersRequest request = new BlockTransfersRequest(height);
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<BlockTransfersRequest, BlockTransfersResult>(url, request, HttpMethod.Post);
        }
        #endregion

        #region Deploy
        public DeployResult GetDeploy(string deployHash)
        {
            DeployRequest request = new DeployRequest(deployHash);
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<DeployRequest, DeployResult>(url, request, HttpMethod.Post);
        }
        #endregion

        #region EraInfo
        public EraInfoResult GetEraInfoLast()
        {
            EraInfoRequest request = new EraInfoRequest();
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<EraInfoRequest, EraInfoResult>(url, request, HttpMethod.Post);
        }

        public EraInfoResult GetEraInfoByHash(string hash)
        {
            EraInfoRequest request = new EraInfoRequest(hash);
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<EraInfoRequest, EraInfoResult>(url, request, HttpMethod.Post);
        }

        public EraInfoResult GetEraInfoByHeight(string height)
        {
            EraInfoRequest request = new EraInfoRequest(height);
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<EraInfoRequest, EraInfoResult>(url, request, HttpMethod.Post);
        }
        #endregion

        #region Metrics
        public string GetNodeMetrics(string url)
        {
            return RpcService.GetClient(url);
        }

        #endregion

        #region Node
        public NodeStatusResult GetNodeStatus()
        {
            RPCSchemaRequest request = new RPCSchemaRequest();
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<RPCSchemaRequest, NodeStatusResult>(url, request, HttpMethod.Post);
        }
        #endregion

        #region RPCSchema
        public string GetRPCShema()
        {
            RPCSchemaRequest request = new RPCSchemaRequest();
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<RPCSchemaRequest>(url, request, HttpMethod.Post);
        }
        #endregion

        #region StateItem
        public StateItemResult GetStateItem(string key)
        {
            var stateRootHash = GetStateRootHash();

            StateItemRequest request = new StateItemRequest(stateRootHash.result.state_root_hash, key);
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<StateItemRequest, StateItemResult>(url, request, HttpMethod.Post);
        }
        #endregion

        #region NodePeers
        public NodePeersResult GetNodePeers()
        {
            NodePeersRequest request = new NodePeersRequest();
            request.jsonrpc = "2.0";
            request.id = "0";

            return RpcService.RpcClient<NodePeersRequest, NodePeersResult>(url, request, HttpMethod.Post);
        }
        #endregion

        #region Hashing
        public string GetAccountHashFromKey(string accountKey)
        {
            return HashService.GetAccountHashFromKey(accountKey);
        }
        #endregion
    }
}
