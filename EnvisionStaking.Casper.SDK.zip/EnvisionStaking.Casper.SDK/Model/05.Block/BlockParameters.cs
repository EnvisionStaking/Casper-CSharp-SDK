﻿using EnvisionStaking.Casper.SDK.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Model.Block
{
    public class BlockParameters
    {
        public string block_identifier { get; set; }
    }
}
