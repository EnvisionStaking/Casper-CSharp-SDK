﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Model.EraInfo
{
    public class EraInfoResult : Base.Result
    {
        public ResultBody result { get; set; }

        public class ResultBody
        {
            public string api_version { get; set; }
            public EraSummary era_summary { get; set; }
        }

        public class Delegator
        {
            public string amount { get; set; }
            public string delegator_public_key { get; set; }
            public string validator_public_key { get; set; }
        }

        public class Validator
        {
            public string amount { get; set; }
            public string validator_public_key { get; set; }
        }

        public class SeigniorageAllocation
        {
            public Delegator Delegator { get; set; }
            public Validator Validator { get; set; }
        }

        public class EraInfo
        {
            public List<SeigniorageAllocation> seigniorage_allocations { get; set; }
        }

        public class StoredValue
        {
            public EraInfo EraInfo { get; set; }
        }

        public class EraSummary
        {
            public string block_hash { get; set; }
            public int era_id { get; set; }
            public string merkle_proof { get; set; }
            public string state_root_hash { get; set; }
            public StoredValue stored_value { get; set; }
        }
    }
}
