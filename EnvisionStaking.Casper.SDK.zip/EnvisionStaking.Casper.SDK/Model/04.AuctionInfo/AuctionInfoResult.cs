﻿using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Model.AuctionInfo
{
    public class AuctionInfoResult : Base.Result
    {
        public ResultBody result { get; set; }
    }

    public class ResultBody
    {
        public string api_version { get; set; }
        public AuctionState auction_state { get; set; }
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class ValidatorWeight
    {
        public string public_key { get; set; }
        public string weight { get; set; }
    }

    public class EraValidator
    {
        public int era_id { get; set; }
        public List<ValidatorWeight> validator_weights { get; set; }
    }

    public class Delegator
    {
        public string public_key { get; set; }
        public string staked_amount { get; set; }
        public string bonding_purse { get; set; }
        public string delegatee { get; set; }
    }

    public class Bid2
    {
        public string bonding_purse { get; set; }
        public string staked_amount { get; set; }
        public int delegation_rate { get; set; }
        public List<Delegator> delegators { get; set; }
        public bool inactive { get; set; }
    }

    public class Bid
    {
        public string public_key { get; set; }
        public Bid bid { get; set; }
    }

    public class AuctionState
    {
        public string state_root_hash { get; set; }
        public int block_height { get; set; }
        public List<EraValidator> era_validators { get; set; }
        public List<Bid> bids { get; set; }
    }



}
