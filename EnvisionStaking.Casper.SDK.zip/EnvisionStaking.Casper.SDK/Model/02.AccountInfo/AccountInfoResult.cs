﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Model.AccountInfo
{
    public class AccountInfoResult : Base.Result    {
        public ResultBody result { get; set; }
    }
    public class AssociatedKey
    {
        public string account_hash { get; set; }
        public int weight { get; set; }
    }

    public class ActionThresholds
    {
        public int deployment { get; set; }
        public int key_management { get; set; }
    }

    public class Account
    {
        public string account_hash { get; set; }
        public List<object> named_keys { get; set; }
        public string main_purse { get; set; }
        public List<AssociatedKey> associated_keys { get; set; }
        public ActionThresholds action_thresholds { get; set; }
    }

    public class ResultBody
    {
        public string api_version { get; set; }
        public Account account { get; set; }
        public string merkle_proof { get; set; }
    }
}
