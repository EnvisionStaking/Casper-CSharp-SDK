﻿using EnvisionStaking.Casper.SDK.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Model.AccountInfo
{
    public class AccountInfoParameters
    {
        public string public_key { get; set; }
    }
}
