﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Model.StateItem
{
    public class StateItemResult : Base.Result
    {
        public ResultBody result { get; set; }
    }
    public class ResultBody
    {
        public string api_version { get; set; }
        public StoredValue stored_value { get; set; }
        public string merkle_proof { get; set; }
    }

    public class StoredValue
    {
        public DeployInfo DeployInfo { get; set; }
        public Account Account { get; set; }
        public CLValue CLValue { get; set; }
        public string ContractWasm { get; set; }
        public Transfer Transfer { get; set; }
        public Contract Contract { get; set; }
        public ContractPackage ContractPackage { get; set; }
        public Bid Bid { get; set; }
        public List<Withdraw> Withdraw { get; set; }

        public EraInfo EraInfo { get; set; }
    }

    #region Deploy
    public class DeployInfo
    {
        public string deploy_hash { get; set; }
        public List<string> transfers { get; set; }
        public string from { get; set; }
        public string source { get; set; }
        public string gas { get; set; }
    }
    #endregion

    #region Account
    public class AssociatedKey
    {
        public string account_hash { get; set; }
        public int weight { get; set; }
    }

    public class ActionThresholds
    {
        public int deployment { get; set; }
        public int key_management { get; set; }
    }

    public class Account
    {
        public string account_hash { get; set; }
        public List<object> named_keys { get; set; }
        public string main_purse { get; set; }
        public List<AssociatedKey> associated_keys { get; set; }
        public ActionThresholds action_thresholds { get; set; }
    }
    #endregion

    #region CLValue
    public class CLValue
    {
        public string cl_type { get; set; }
        public string bytes { get; set; }
        public object parsed { get; set; }
    }
    #endregion

    #region Transfer
    public class Transfer
    {
        public string deploy_hash { get; set; }
        public string from { get; set; }
        public string to { get; set; }
        public string source { get; set; }
        public string target { get; set; }
        public string amount { get; set; }
        public string gas { get; set; }
        public object id { get; set; }
    }
    #endregion

    #region Contract
    public class NamedKey
    {
        public string name { get; set; }
        public string key { get; set; }
    }

    public class Arg
    {
        public string name { get; set; }
        public object cl_type { get; set; }
    }

    public class EntryPoint
    {
        public string name { get; set; }
        public List<Arg> args { get; set; }
        public object ret { get; set; }
        public string access { get; set; }
        public string entry_point_type { get; set; }
    }

    public class Contract
    {
        public string contract_package_hash { get; set; }
        public string contract_wasm_hash { get; set; }
        public List<NamedKey> named_keys { get; set; }
        public List<EntryPoint> entry_points { get; set; }
        public string protocol_version { get; set; }
    }
    #endregion

    #region ContractPackage
    public class Version
    {
        public int protocol_version_major { get; set; }
        public int contract_version { get; set; }
        public string contract_hash { get; set; }
    }

    public class ContractPackage
    {
        public string access_key { get; set; }
        public List<Version> versions { get; set; }
        public List<object> disabled_versions { get; set; }
        public List<object> groups { get; set; }
    }
    #endregion

    #region Bid
    public class Bid
    {
        public string validator_public_key { get; set; }
        public string bonding_purse { get; set; }
        public string staked_amount { get; set; }
        public int delegation_rate { get; set; }
        public object vesting_schedule { get; set; }
        public JObject delegators { get; set; }
        public bool inactive { get; set; }
    }
    #endregion

    #region Withdraw
    public class Withdraw
    {
        public string bonding_purse { get; set; }
        public string validator_public_key { get; set; }
        public string unbonder_public_key { get; set; }
        public int era_of_creation { get; set; }
        public string amount { get; set; }
    }
    #endregion

    #region EraInfo

    public class EraInfo
    {
        public List<SeigniorageAllocation> seigniorage_allocations { get; set; }
    }

    public class Delegator
    {
        public string amount { get; set; }
        public string delegator_public_key { get; set; }
        public string validator_public_key { get; set; }
    }

    public class Validator
    {
        public string amount { get; set; }
        public string validator_public_key { get; set; }
    }

    public class SeigniorageAllocation
    {
        public Delegator Delegator { get; set; }
        public Validator Validator { get; set; }
    }

    #endregion
}
