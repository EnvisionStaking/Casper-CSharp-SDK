﻿using EnvisionStaking.Casper.SDK.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Model.BlockTransfers
{
    public class BlockTransfersParameters
    {
        public string block_identifier { get; set; }
    }
}
