﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Model.Deploy
{
    public class DeployResult : Base.Result    {
        public ResultBody result { get; set; }
    }
    public class ResultBody
    {
        public string api_version { get; set; }
        public Deploy deploy { get; set; }
        public List<ExecutionResult> execution_results { get; set; }
    }

    public class Result
    {
        public Success Success { get; set; }
        public string api_version { get; set; }
        public Deploy deploy { get; set; }
        public List<ExecutionResult> execution_results { get; set; }
    }

    public class Header
    {
        public string account { get; set; }
        public DateTime timestamp { get; set; }
        public string ttl { get; set; }
        public int gas_price { get; set; }
        public string body_hash { get; set; }
        public List<object> dependencies { get; set; }
        public string chain_name { get; set; }
    }

    public class ModuleBytes
    {
        public string module_bytes { get; set; }
        public List<List<object>> args { get; set; }
    }

    public class Payment
    {
        public ModuleBytes ModuleBytes { get; set; }
    }

    public class Transfer
    {
        public List<List<object>> args { get; set; }
    }

    public class Session
    {
        public Transfer Transfer { get; set; }
    }

    public class Approval
    {
        public string signer { get; set; }
        public string signature { get; set; }
    }

    public class Deploy
    {
        public string hash { get; set; }
        public Header header { get; set; }
        public Payment payment { get; set; }
        public Session session { get; set; }
        public List<Approval> approvals { get; set; }
    }

    public class Operation
    {
        public string key { get; set; }
        public string kind { get; set; }
    }

    public class Transform
    {
        public string key { get; set; }
        public object transform { get; set; }
    }

    public class Effect
    {
        public List<Operation> operations { get; set; }
        public List<Transform> transforms { get; set; }
    }

    public class Success
    {
        public Effect effect { get; set; }
        public List<string> transfers { get; set; }
        public string cost { get; set; }
    }

    public class ExecutionResult
    {
        public string block_hash { get; set; }
        public Result result { get; set; }
    }
}
