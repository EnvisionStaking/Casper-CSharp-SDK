﻿using EnvisionStaking.Casper.SDK.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Model.Deploy
{
    public class DeployParameters
    {
        public string deploy_hash { get; set; }
    }
}
