﻿using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Model.NodePeers
{
    public class NodePeersResult : Base.Result
    {
        public ResultBody result { get; set; }
    }

    public class ResultBody
    {
        public string api_version { get; set; }
        public List<Peer> peers { get; set; }
    }

    public class Peer
    {
        public string node_id { get; set; }
        public string address { get; set; }
    }
}



