﻿using Org.BouncyCastle.Cms;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Utilities.IO.Pem;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Services
{
    public class SigningService
    {

    public AsymmetricCipherKeyPair LoadKeyPair(File publicKeyFile, File privateKeyFile)
        {
            return loadKeyPair(new FileInputStream(publicKeyFile), new FileInputStream(privateKeyFile));
        }

        public AsymmetricCipherKeyPair loadKeyPair(InputStream publicKeyIn, InputStream privateKeyIn)
        {
            byte[] publicBytes = ReadPem(publicKeyIn);
            byte[] secretBytes = ReadPem(privateKeyIn);
            return new AsymmetricCipherKeyPair(new Ed25519PublicKeyParameters(publicBytes), new Ed25519PrivateKeyParameters(secretBytes));
        }

        public AsymmetricCipherKeyPair generateEdDSAKey()
        {
            SecureRandom RANDOM = new SecureRandom();
            Ed25519KeyPairGenerator keyPairGenerator = new Ed25519KeyPairGenerator();
            keyPairGenerator.init(new Ed25519KeyGenerationParameters(RANDOM));
            return keyPairGenerator.generateKeyPair();
        }

        public byte[] signWithPrivateKey(AsymmetricKeyParameter privateKey, byte[] toSign)
        {
            try
            {
                SignerID signer = new Ed25519Signer();
                signer.init(true, privateKey);
                signer.update(toSign, 0, toSign.length);
                return signer.generateSignature();
            }
            catch (CryptoException)
            {
            }

            DataLengthException e;
            throw new IllegalArgumentException("Failed to generate signature :", e.getCause());
        }

        private Signer generateEdDSAKey(byte[] privateKeyBytes)
        {
            Ed25519PrivateKeyParameters privateKeyParameters = new Ed25519PrivateKeyParameters(privateKeyBytes, 0);
            Ed25519Signer ed25519Signer = new Ed25519Signer();
            ed25519Signer.init(true, privateKeyParameters);
            return ed25519Signer;
        }

        public bool verifySignature(AsymmetricKeyParameter publicKeyParameters, byte[] toSign, byte[] signature)
        {
            Signer verifier = new Ed25519Signer();
            verifier.init(false, publicKeyParameters);
            verifier.update(toSign, 0, toSign.length);
            return verifier.verifySignature(signature);
        }

        public static byte[] ReadPem(string accountKey)
        {
            var pemReader = new Org.BouncyCastle.OpenSsl.PemReader(new StringReader(accountKey));
            var pemObject = pemReader.ReadPemObject();
            return pemObject.Content;
        }
    }
}
