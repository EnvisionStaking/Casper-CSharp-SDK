﻿using EnvisionStaking.Casper.SDK.Model.Base;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace EnvisionStaking.Casper.SDK.Services
{
    public static class RpcService
    {
        public static K RpcClient<T, K>(string url, T request, HttpMethod httpMethod)
        {
            string result = RpcClient<T>(url, request, httpMethod);
            var temp = JsonConvert.DeserializeObject<K>(result);
            var tempResultObject = temp as Result;
            if(tempResultObject.error!=null)
            {
                HandleRpcException(tempResultObject.error);
            }
            return temp;
        }

        public static string RpcClient<T>(string url, T request, HttpMethod httpMethod)
        {
            string jsonString = JsonConvert.SerializeObject(request);
            var data = new StringContent(jsonString);
            using (var httpClient = new HttpClient())
            {

                HttpRequestMessage msg = new HttpRequestMessage(httpMethod, url);

                msg.Content = new StringContent(jsonString);
                msg.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                HttpResponseMessage response = httpClient.SendAsync(msg).Result;

                response.EnsureSuccessStatusCode();

                string result = response.Content.ReadAsStringAsync().Result;
                return result;
            }
        }

        public static K GetClient<K>(string url)
        {
            string result = GetClient(url);
            var temp = JsonConvert.DeserializeObject<K>(result);
            var tempResultObject = temp as Result;
            if (tempResultObject.error != null)
            {
                HandleRpcException(tempResultObject.error);
            }
            return temp;
        }

        public static string GetClient(string Url)
        {
            using (var httpClient = new HttpClient())
            {
                HttpRequestMessage msg = new HttpRequestMessage(HttpMethod.Get, Url);

                HttpResponseMessage response = httpClient.SendAsync(msg).Result;
                response.EnsureSuccessStatusCode();

                string result = response.Content.ReadAsStringAsync().Result;
                return result;
            }
        }

        public static string HandleRpcException(Error error)
        {
            throw new ApplicationException(error.message);
        }
    }
}
